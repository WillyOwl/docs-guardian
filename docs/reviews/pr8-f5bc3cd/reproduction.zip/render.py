"""Render complete captured output for real browser screenshots."""
import html
import json
from pathlib import Path
import re

out = Path(__file__).resolve().parent
commit = 'f5bc3cdc8df0b58fb702a1db04fb836de5de06db'
style = '''
* { box-sizing: border-box; }
body { margin: 0; padding: 28px; background: #101820; color: #e8edf2;
       font-family: Arial, sans-serif; }
h1 { font-size: 26px; margin: 0 0 12px; } h2 { font-size: 20px; margin: 24px 0 12px; }
.meta { font: 15px/1.5 monospace; color: #acbed1; }
pre { background: #192530; border: 1px solid #3c4b5a; padding: 18px;
      border-radius: 6px; font: 14px/21px "DejaVu Sans Mono", monospace;
      white-space: pre-wrap; overflow-wrap: anywhere; margin: 0; }
'''
groups = [
    ('tests', 'PR #8 | repository tests on Python 3.11 and 3.14', [
        ('Python 3.14 | 60 passed', 'pytest-3.14'),
        ('Python 3.11 | 60 passed (isolated environment)', 'pytest-3.11'),
    ]),
    ('quality-and-pages', 'PR #8 | lint, Markdown, notebook and strict docs build', [
        ('Ruff lint', 'quality'), ('Ruff format', 'format'),
        ('Markdown Pages', 'snippets'), ('Notebook', 'notebooks'),
        ('Strict MkDocs build', 'mkdocs'),
    ]),
    ('previous-review', 'PR #8 | all eight previous independent regressions pass', [
        ('Original test scripts, unmodified | 8 passed', 'previous-review'),
    ]),
    ('lifecycle-review', 'PR #8 | additional process, parser and traceback checks', [
        ('Success / exception / timeout cleanup, next Page, Markdown and Unicode | 5 passed',
         'lifecycle-review'),
    ]),
    ('notebooks-sandbox', 'PR #8 | initial notebook attempt blocked by sandbox', [
        ('Environment restriction: local sockets denied; rerun outside sandbox passed',
         'notebooks-sandbox'),
    ]),
]
jobs = []
for slug, title, sections in groups:
    body = ''
    for label, name in sections:
        raw = (out / (name + '.txt')).read_text()
        display = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', raw)
        body += '<h2>' + html.escape(label) + '</h2><pre>' + html.escape(display) + '</pre>'
    document = ('<!doctype html><html lang="en"><meta charset="utf-8"><title>' +
        html.escape(title) + '</title><style>' + style + '</style><h1>' +
        html.escape(title) + '</h1><p class="meta">Reviewed commit: ' + commit +
        '<br>Complete captured command output (terminal color codes removed for display). '
        'Commands, timestamps and exit codes are included. Source commit is unchanged.</p>' + body)
    (out / (slug + '.html')).write_text(document)
    jobs.append(slug)
(out / 'screenshot-jobs.json').write_text(json.dumps(jobs, indent=2) + '\n')
print('Built', len(jobs), 'local evidence pages')
